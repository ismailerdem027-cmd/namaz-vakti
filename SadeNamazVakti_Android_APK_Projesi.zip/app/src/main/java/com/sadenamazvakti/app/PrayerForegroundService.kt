package com.sadenamazvakti.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.util.concurrent.Executors

/**
 * Özellik 2 & 3:
 * - Hiç kapanmayan sürekli bildirim (Ongoing Foreground Service).
 * - Tüm vakitleri (İmsak, Güneş, Öğle, İkindi, Akşam, Yatsı) bildirimde gösterir.
 * - Her dakika (ACTION_TIME_TICK) güncellenir; son 60 dakikada sol üst simgede kalan dakikayı yazar.
 */
class PrayerForegroundService : Service() {

    companion object {
        const val CHANNEL_ID = "sade_namaz_ongoing_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_REFRESH = "com.sadenamazvakti.app.ACTION_REFRESH"
    }

    private val executor = Executors.newSingleThreadExecutor()

    private val timeTickReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshNotificationAsync()
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()

        // İlk bildirimi hemen başlat
        val fallback = DiyanetRepository.fetchAndCacheDiyanetTimes(this)
        if (fallback != null) {
            val nextInfo = DiyanetRepository.calculateNextPrayer(fallback)
            startForeground(NOTIFICATION_ID, buildOngoingNotification(nextInfo))
        }

        // Her dakika sistem saati değiştiğinde ve saat dilimi değiştiğinde bildirimi güncelle
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
        }
        registerReceiver(timeTickReceiver, filter)
        refreshNotificationAsync()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        refreshNotificationAsync()
        // START_STICKY sayesinde sistem belleği temizlese bile servis otomatik yeniden başlar
        return START_STICKY
    }

    private fun refreshNotificationAsync() {
        executor.execute {
            val times = DiyanetRepository.fetchAndCacheDiyanetTimes(this) ?: return@execute
            val nextInfo = DiyanetRepository.calculateNextPrayer(times)
            val notification = buildOngoingNotification(nextInfo)
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIFICATION_ID, notification)
            AlarmScheduler.scheduleAllEnabledAlarms(this, times)
        }
    }

    private fun buildOngoingNotification(info: NextPrayerInfo): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val hours = info.remainingMinutes / 60
        val mins = info.remainingMinutes % 60
        val countdownStr = if (hours > 0) {
            "${hours} sa ${mins} dk"
        } else {
            "${mins} dk"
        }

        val t = info.todayTimes
        val title = "${info.prayerName} vaktine $countdownStr kaldı (${info.prayerTime}) • ${t.cityName}"
        val compactLine = "İms:${t.imsak}  Gün:${t.gunes}  Öğl:${t.ogle}  İkn:${t.ikindi}  Akş:${t.aksam}  Yat:${t.yatsi}"
        val expandedText =
            "İmsak: ${t.imsak}   |   Güneş: ${t.gunes}   |   Öğle: ${t.ogle}
" +
            "İkindi: ${t.ikindi}   |   Akşam: ${t.aksam}   |   Yatsı: ${t.yatsi}"

        // Sol üst durum çubuğu simgesi (Son 60 dk içinde dakikayı yazar)
        val smallIcon = StatusBarIconGenerator.createStatusBarIcon(info.remainingMinutes)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(smallIcon)
            .setContentTitle(title)
            .setContentText(compactLine)
            .setStyle(NotificationCompat.BigTextStyle().bigText(expandedText))
            .setOngoing(true)                  // Kullanıcı sağa/sola kaydırarak kapatamaz
            .setAutoCancel(false)              // Tıklanınca kapanmaz
            .setOnlyAlertOnce(true)            // Her dakika güncellenirken ses/titreşim yapmaz
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC) // Kilit ekranında da görünür
            .setContentIntent(pendingIntent)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Sürekli Namaz Vakitleri Bildirimi",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Namaz vakitlerini ve kalan dakikayı sürekli durum çubuğunda gösterir"
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(timeTickReceiver)
        } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
