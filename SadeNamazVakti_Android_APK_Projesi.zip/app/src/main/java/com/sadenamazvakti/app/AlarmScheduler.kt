package com.sadenamazvakti.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import android.provider.AlarmClock
import java.util.Calendar

data class PrayerAlarmConfig(
    val prayerIndex: Int,
    val prayerName: String,
    val exactAlarmEnabled: Boolean,
    val beforeAlarmEnabled: Boolean,
    val minutesBefore: Int,
    val ringtoneUri: String?
)

object AlarmScheduler {
    private const val PREFS_ALARM = "prayer_alarm_prefs"

    val PRAYER_NAMES = listOf("İmsak", "Güneş", "Öğle", "İkindi", "Akşam", "Yatsı")

    fun saveConfig(context: Context, config: PrayerAlarmConfig) {
        val prefs = context.getSharedPreferences(PREFS_ALARM, Context.MODE_PRIVATE)
        val p = "p_${config.prayerIndex}_"
        prefs.edit()
            .putBoolean(p + "exact", config.exactAlarmEnabled)
            .putBoolean(p + "before", config.beforeAlarmEnabled)
            .putInt(p + "mins", config.minutesBefore)
            .putString(p + "uri", config.ringtoneUri)
            .apply()
    }

    fun getConfig(context: Context, index: Int): PrayerAlarmConfig {
        val prefs = context.getSharedPreferences(PREFS_ALARM, Context.MODE_PRIVATE)
        val p = "p_${index}_"
        val defaultUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)?.toString()
        return PrayerAlarmConfig(
            prayerIndex = index,
            prayerName = PRAYER_NAMES[index],
            exactAlarmEnabled = prefs.getBoolean(p + "exact", false),
            beforeAlarmEnabled = prefs.getBoolean(p + "before", false),
            minutesBefore = prefs.getInt(p + "mins", 15),
            ringtoneUri = prefs.getString(p + "uri", defaultUri)
        )
    }

    /**
     * Her gün Diyanet vakitleri yenilendiğinde tüm aktif alarmları yeni günün dakikasına göre
     * Android'in resmi Sistem Saat Alarmı (setAlarmClock) olarak otomatik günceller.
     * Örneğin Güneş vaktinden 15 dk önce dün 06:41 ise bugün otomatik 06:42'ye kurulur.
     */
    fun scheduleAllEnabledAlarms(context: Context, today: DailyPrayerTimes) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val timesList = today.asOrderedList()

        for (i in timesList.indices) {
            val (name, timeStr) = timesList[i]
            val cfg = getConfig(context, i)

            // 1. Tam vakit sistem saat alarmı (Request Code: 200 + i)
            cancelSingleAlarm(context, alarmManager, 200 + i)
            if (cfg.exactAlarmEnabled) {
                val triggerMs = computeNextTriggerMillis(timeStr, 0)
                scheduleAsSystemAlarmClock(
                    context,
                    alarmManager,
                    200 + i,
                    triggerMs,
                    "$name Vakti ($timeStr)",
                    cfg.ringtoneUri
                )
            }

            // 2. Vakit öncesi sistem saat alarmı (Request Code: 300 + i)
            // Örn: Güneşten 15 dk önce -> Her gün yeni güneş vaktine göre otomatik güncellenir
            cancelSingleAlarm(context, alarmManager, 300 + i)
            if (cfg.beforeAlarmEnabled && cfg.minutesBefore > 0) {
                val triggerMs = computeNextTriggerMillis(timeStr, cfg.minutesBefore)
                scheduleAsSystemAlarmClock(
                    context,
                    alarmManager,
                    300 + i,
                    triggerMs,
                    "$name vaktine ${cfg.minutesBefore} dk kaldı ($timeStr)",
                    cfg.ringtoneUri
                )
            }
        }
    }

    /**
     * İsteğe bağlı olarak telefonun kendi yerleşik Saat (Clock) uygulamasının içine de
     * hesaplanan dakikayı doğrudan kurar (AlarmClock.ACTION_SET_ALARM).
     */
    fun setInNativeClockApp(context: Context, timeHhMm: String, subtractMinutes: Int, label: String) {
        val parts = timeHhMm.split(":")
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, parts[0].toInt())
            set(Calendar.MINUTE, parts[1].toInt())
            add(Calendar.MINUTE, -subtractMinutes)
        }
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, cal.get(Calendar.HOUR_OF_DAY))
            putExtra(AlarmClock.EXTRA_MINUTES, cal.get(Calendar.MINUTE))
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) {}
    }

    private fun computeNextTriggerMillis(timeHhMm: String, subtractMinutes: Int): Long {
        val parts = timeHhMm.split(":")
        val hour = parts[0].toInt()
        val minute = parts[1].toInt()

        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            add(Calendar.MINUTE, -subtractMinutes)
        }
        if (cal.timeInMillis <= System.currentTimeMillis()) {
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return cal.timeInMillis
    }

    /**
     * AlarmManager.setAlarmClock kullanarak telefonun gerçek Sistem Saat Alarmı olarak kurar.
     * Kilit ekranında ve durum çubuğunda telefonun kendi saat alarmı simgesiyle görünür
     * ve her gün vakit değiştikçe eski alarmın üzerine yazılarak otomatik güncellenir.
     */
    private fun scheduleAsSystemAlarmClock(
        context: Context,
        alarmManager: AlarmManager,
        requestCode: Int,
        triggerAtMillis: Long,
        label: String,
        ringtoneUri: String?
    ) {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra("ALARM_LABEL", label)
            putExtra("RINGTONE_URI", ringtoneUri)
        }
        val operationPi = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val showIntent = Intent(context, MainActivity::class.java)
        val showPi = PendingIntent.getActivity(
            context,
            requestCode,
            showIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            val alarmClockInfo = AlarmManager.AlarmClockInfo(triggerAtMillis, showPi)
            alarmManager.setAlarmClock(alarmClockInfo, operationPi)
        } catch (_: SecurityException) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, operationPi)
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, operationPi)
            }
        }
    }

    private fun cancelSingleAlarm(context: Context, alarmManager: AlarmManager, requestCode: Int) {
        val intent = Intent(context, AlarmReceiver::class.java)
        val pi = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pi)
    }
}
