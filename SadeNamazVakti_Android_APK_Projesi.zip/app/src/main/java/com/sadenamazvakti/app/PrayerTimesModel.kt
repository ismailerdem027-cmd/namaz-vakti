package com.sadenamazvakti.app

data class DailyPrayerTimes(
    val dateKey: String,      // YYYY-MM-DD
    val cityName: String,
    val imsak: String,        // HH:mm
    val gunes: String,
    val ogle: String,
    val ikindi: String,
    val aksam: String,
    val yatsi: String
) {
    fun asOrderedList(): List<Pair<String, String>> = listOf(
        "İmsak" to imsak,
        "Güneş" to gunes,
        "Öğle" to ogle,
        "İkindi" to ikindi,
        "Akşam" to aksam,
        "Yatsı" to yatsi
    )
}

data class NextPrayerInfo(
    val prayerName: String,
    val prayerTime: String,
    val remainingMinutes: Int,
    val todayTimes: DailyPrayerTimes
)
