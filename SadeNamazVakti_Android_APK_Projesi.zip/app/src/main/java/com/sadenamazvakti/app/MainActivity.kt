package com.sadenamazvakti.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.location.LocationManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var headerCityText: TextView
    private lateinit var countdownText: TextView
    private lateinit var timesContainer: LinearLayout
    private var pendingRingtonePrayerIndex: Int = -1

    companion object {
        private const val REQ_PERMISSIONS = 101
        private const val REQ_RINGTONE_PICKER = 102
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupUi()
        requestNecessaryPermissions()
        startOngoingPrayerService()
        refreshScreenData()
    }

    private fun setupUi() {
        val rootScroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0F172A"))
        }
        val mainColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 56, 40, 56)
        }

        headerCityText = TextView(this).apply {
            text = "Diyanet Namaz Vakitleri"
            textSize = 22f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        mainColumn.addView(headerCityText)

        countdownText = TextView(this).apply {
            text = "Vakitler yükleniyor..."
            textSize = 16f
            setTextColor(Color.parseColor("#38BDF8"))
            setPadding(0, 12, 0, 28)
        }
        mainColumn.addView(countdownText)

        val btnUpdateLocation = Button(this).apply {
            text = "Konumu Güncelle & Diyanet Vakitlerini Yenile"
            setOnClickListener { detectLocationAndRefresh() }
        }
        mainColumn.addView(btnUpdateLocation)

        val infoNote = TextView(this).apply {
            text = "• Sürekli bildirim aktiftir (kapanmaz).
• Son 1 saat kaldığında sol üstteki simgede kalan dakika yazar.
• Aşağıdan her vakit için alarm ve zil sesi seçebilirsiniz."
            textSize = 13f
            setTextColor(Color.parseColor("#94A3B8"))
            setPadding(0, 20, 0, 28)
        }
        mainColumn.addView(infoNote)

        timesContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        mainColumn.addView(timesContainer)

        rootScroll.addView(mainColumn)
        setContentView(rootScroll)
    }

    private fun refreshScreenData() {
        executor.execute {
            val today = DiyanetRepository.fetchAndCacheDiyanetTimes(this) ?: return@execute
            val next = DiyanetRepository.calculateNextPrayer(today)
            runOnUiThread {
                headerCityText.text = "${today.cityName} • Diyanet Namaz Vakitleri"
                val h = next.remainingMinutes / 60
                val m = next.remainingMinutes % 60
                countdownText.text = "${next.prayerName} vaktine ${if (h > 0) "$h sa $m dk" else "$m dk"} kaldı (${next.prayerTime})"
                renderPrayerRows(today)
            }
        }
    }

    private fun renderPrayerRows(today: DailyPrayerTimes) {
        timesContainer.removeAllViews()
        val ordered = today.asOrderedList()

        for (i in ordered.indices) {
            val (name, timeStr) = ordered[i]
            val cfg = AlarmScheduler.getConfig(this, i)

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(Color.parseColor("#1E293B"))
                setPadding(32, 28, 32, 28)
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.setMargins(0, 0, 0, 20)
                layoutParams = lp
            }

            val leftCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            val titleTv = TextView(this).apply {
                text = "$name   •   $timeStr"
                textSize = 18f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
            }
            leftCol.addView(titleTv)

            val statusSummary = buildString {
                if (cfg.exactAlarmEnabled) append("Tam vakitte açık  ")
                if (cfg.beforeAlarmEnabled) append("${cfg.minutesBefore} dk önce açık")
                if (!cfg.exactAlarmEnabled && !cfg.beforeAlarmEnabled) append("Alarm kapalı")
            }
            val subTv = TextView(this).apply {
                text = statusSummary
                textSize = 13f
                setTextColor(Color.parseColor("#38BDF8"))
            }
            leftCol.addView(subTv)

            val alarmBtn = Button(this).apply {
                text = "Alarm Ayarla"
                setOnClickListener { showAlarmDialog(i, today) }
            }

            card.addView(leftCol)
            card.addView(alarmBtn)
            timesContainer.addView(card)
        }
    }

    private fun showAlarmDialog(prayerIndex: Int, today: DailyPrayerTimes) {
        val currentCfg = AlarmScheduler.getConfig(this, prayerIndex)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 32, 48, 16)
        }

        val cbExact = CheckBox(this).apply {
            text = "${currentCfg.prayerName} tam vaktinde alarm çalsın"
            isChecked = currentCfg.exactAlarmEnabled
        }
        layout.addView(cbExact)

        val cbBefore = CheckBox(this).apply {
            text = "Vakitten önce alarm çalsın"
            isChecked = currentCfg.beforeAlarmEnabled
        }
        layout.addView(cbBefore)

        val etMinutes = EditText(this).apply {
            hint = "Kaç dakika önce? (Örn: 15, 30, 45)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(currentCfg.minutesBefore.toString())
        }
        layout.addView(etMinutes)

        val cbSyncNativeClock = CheckBox(this).apply {
            text = "Telefonun kendi Saat uygulamasına da ekle"
            isChecked = false
        }
        layout.addView(cbSyncNativeClock)

        val btnPickTone = Button(this).apply {
            text = "Zil Sesi Seç"
            setOnClickListener {
                pendingRingtonePrayerIndex = prayerIndex
                val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                    putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALL)
                    putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "${currentCfg.prayerName} Zil Sesi Seçin")
                    currentCfg.ringtoneUri?.let {
                        putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(it))
                    }
                }
                @Suppress("DEPRECATION")
                startActivityForResult(intent, REQ_RINGTONE_PICKER)
            }
        }
        layout.addView(btnPickTone)

        AlertDialog.Builder(this)
            .setTitle("${currentCfg.prayerName} Alarm Ayarları")
            .setView(layout)
            .setPositiveButton("Kaydet") { _, _ ->
                val latest = AlarmScheduler.getConfig(this, prayerIndex)
                val mins = etMinutes.text.toString().toIntOrNull() ?: 15
                val updated = latest.copy(
                    exactAlarmEnabled = cbExact.isChecked,
                    beforeAlarmEnabled = cbBefore.isChecked,
                    minutesBefore = mins
                )
                AlarmScheduler.saveConfig(this, updated)
                AlarmScheduler.scheduleAllEnabledAlarms(this, today)
                val prayerTimeStr = today.asOrderedList()[prayerIndex].second
                if (cbSyncNativeClock.isChecked) {
                    if (cbExact.isChecked) {
                        AlarmScheduler.setInNativeClockApp(this, prayerTimeStr, 0, "${updated.prayerName} Vakti")
                    }
                    if (cbBefore.isChecked && mins > 0) {
                        AlarmScheduler.setInNativeClockApp(this, prayerTimeStr, mins, "${updated.prayerName} ($mins dk önce)")
                    }
                }
                renderPrayerRows(today)
                Toast.makeText(this, "${updated.prayerName} alarmı kaydedildi", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_RINGTONE_PICKER && resultCode == Activity.RESULT_OK && pendingRingtonePrayerIndex >= 0) {
            @Suppress("DEPRECATION")
            val uri: Uri? = data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            val cfg = AlarmScheduler.getConfig(this, pendingRingtonePrayerIndex)
            AlarmScheduler.saveConfig(this, cfg.copy(ringtoneUri = uri?.toString()))
            Toast.makeText(this, "Zil sesi seçildi", Toast.LENGTH_SHORT).show()
        }
    }

    private fun detectLocationAndRefresh() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestNecessaryPermissions()
            return
        }
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val loc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            ?: lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
        if (loc != null) {
            DiyanetRepository.saveLocation(this, loc.latitude, loc.longitude)
        }
        startOngoingPrayerService()
        refreshScreenData()
        Toast.makeText(this, "Konum ve Diyanet vakitleri güncellendi", Toast.LENGTH_SHORT).show()
    }

    private fun startOngoingPrayerService() {
        val serviceIntent = Intent(this, PrayerForegroundService::class.java)
        ContextCompat.startForegroundService(this, serviceIntent)
    }

    private fun requestNecessaryPermissions() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQ_PERMISSIONS)
        }
    }
}
