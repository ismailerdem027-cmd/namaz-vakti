package com.sadenamazvakti.app

import android.content.Context
import android.location.Geocoder
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Konuma göre Diyanet İşleri Başkanlığı (Method 13) namaz vakitlerini çeker
 * ve internet olmadığında da çalışması için aylık olarak yerel hafızaya kaydeder.
 */
object DiyanetRepository {
    private const val PREFS_NAME = "diyanet_prayer_prefs"
    private const val KEY_LAT = "lat"
    private const val KEY_LON = "lon"
    private const val KEY_CITY = "city"

    // Varsayılan konum: Gaziantep (Kullanıcı konum izni verince otomatik güncellenir)
    private const val DEFAULT_LAT = 37.0662
    private const val DEFAULT_LON = 37.3833
    private const val DEFAULT_CITY = "Gaziantep"

    fun saveLocation(context: Context, lat: Double, lon: Double) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        var cityName = prefs.getString(KEY_CITY, DEFAULT_CITY) ?: DEFAULT_CITY
        try {
            val geocoder = Geocoder(context, Locale("tr", "TR"))
            @Suppress("DEPRECATION")
            val addresses = geocoder.getFromLocation(lat, lon, 1)
            if (!addresses.isNullOrEmpty()) {
                val addr = addresses[0]
                cityName = addr.subAdminArea ?: addr.adminArea ?: DEFAULT_CITY
            }
        } catch (_: Exception) {}

        prefs.edit()
            .putString(KEY_LAT, lat.toString())
            .putString(KEY_LON, lon.toString())
            .putString(KEY_CITY, cityName)
            .apply()
    }

    fun getSavedLocation(context: Context): Triple<Double, Double, String> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val lat = prefs.getString(KEY_LAT, null)?.toDoubleOrNull() ?: DEFAULT_LAT
        val lon = prefs.getString(KEY_LON, null)?.toDoubleOrNull() ?: DEFAULT_LON
        val city = prefs.getString(KEY_CITY, DEFAULT_CITY) ?: DEFAULT_CITY
        return Triple(lat, lon, city)
    }

    /**
     * Diyanet İşleri Başkanlığı (method=13) verilerini çeker ve önbelleğe yazar.
     */
    fun fetchAndCacheDiyanetTimes(context: Context, date: Date = Date()): DailyPrayerTimes? {
        val (lat, lon, city) = getSavedLocation(context)
        val dateKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(date)
        val apiDate = SimpleDateFormat("dd-MM-yyyy", Locale.US).format(date)

        // Önce önbellekte var mı kontrol et
        getCachedTimes(context, dateKey)?.let { return it }

        return try {
            // method=13 -> Diyanet İşleri Başkanlığı, Türkiye resmi hesaplama/veri kaynağı
            val urlStr = "https://api.aladhan.com/v1/timings/$apiDate?latitude=$lat&longitude=$lon&method=13"
            val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                requestMethod = "GET"
            }
            if (conn.responseCode == 200) {
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                val timings = JSONObject(response)
                    .getJSONObject("data")
                    .getJSONObject("timings")

                val daily = DailyPrayerTimes(
                    dateKey = dateKey,
                    cityName = city,
                    imsak = cleanTime(timings.getString("Fajr")),
                    gunes = cleanTime(timings.getString("Sunrise")),
                    ogle = cleanTime(timings.getString("Dhuhr")),
                    ikindi = cleanTime(timings.getString("Asr")),
                    aksam = cleanTime(timings.getString("Maghrib")),
                    yatsi = cleanTime(timings.getString("Isha"))
                )
                cacheTimes(context, daily)
                daily
            } else {
                getFallbackOrCached(context, dateKey, city)
            }
        } catch (e: Exception) {
            getFallbackOrCached(context, dateKey, city)
        }
    }

    private fun cleanTime(raw: String): String {
        return raw.trim().take(5)
    }

    private fun cacheTimes(context: Context, daily: DailyPrayerTimes) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val json = JSONObject().apply {
            put("dateKey", daily.dateKey)
            put("cityName", daily.cityName)
            put("imsak", daily.imsak)
            put("gunes", daily.gunes)
            put("ogle", daily.ogle)
            put("ikindi", daily.ikindi)
            put("aksam", daily.aksam)
            put("yatsi", daily.yatsi)
        }
        prefs.edit().putString("day_${daily.dateKey}", json.toString()).apply()
    }

    fun getCachedTimes(context: Context, dateKey: String): DailyPrayerTimes? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString("day_$dateKey", null) ?: return null
        return try {
            val j = JSONObject(raw)
            DailyPrayerTimes(
                dateKey = j.getString("dateKey"),
                cityName = j.getString("cityName"),
                imsak = j.getString("imsak"),
                gunes = j.getString("gunes"),
                ogle = j.getString("ogle"),
                ikindi = j.getString("ikindi"),
                aksam = j.getString("aksam"),
                yatsi = j.getString("yatsi")
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun getFallbackOrCached(context: Context, dateKey: String, city: String): DailyPrayerTimes {
        getCachedTimes(context, dateKey)?.let { return it }
        return DailyPrayerTimes(
            dateKey = dateKey,
            cityName = city,
            imsak = "05:34",
            gunes = "06:56",
            ogle = "12:24",
            ikindi = "15:18",
            aksam = "17:41",
            yatsi = "18:58"
        )
    }

    /**
     * Şu anki saate göre sıradaki vakti ve kalan dakikayı hesaplar.
     */
    fun calculateNextPrayer(today: DailyPrayerTimes): NextPrayerInfo {
        val now = Calendar.getInstance()
        val nowMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)

        for ((name, timeStr) in today.asOrderedList()) {
            val parts = timeStr.split(":")
            if (parts.size == 2) {
                val pMin = parts[0].toInt() * 60 + parts[1].toInt()
                if (pMin > nowMinutes) {
                    return NextPrayerInfo(
                        prayerName = name,
                        prayerTime = timeStr,
                        remainingMinutes = pMin - nowMinutes,
                        todayTimes = today
                    )
                }
            }
        }

        // Yatsı geçtiyse sıradaki vakit yarının İmsak vaktidir
        val parts = today.imsak.split(":")
        val imsakMin = parts[0].toInt() * 60 + parts[1].toInt()
        val remaining = (24 * 60 - nowMinutes) + imsakMin
        return NextPrayerInfo(
            prayerName = "İmsak",
            prayerTime = today.imsak,
            remainingMinutes = remaining,
            todayTimes = today
        )
    }
}
