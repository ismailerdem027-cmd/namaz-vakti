package com.sadenamazvakti.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val label = intent.getStringExtra("ALARM_LABEL") ?: "Namaz Vakti Alarmı"
        val ringtoneUri = intent.getStringExtra("RINGTONE_URI")

        val serviceIntent = Intent(context, AlarmRingService::class.java).apply {
            putExtra("ALARM_LABEL", label)
            putExtra("RINGTONE_URI", ringtoneUri)
        }
        ContextCompat.startForegroundService(context, serviceIntent)

        // Alarm çaldıktan hemen sonra bir sonraki günün değişen Diyanet vaktine göre sistem alarmını otomatik güncelle
        Executors.newSingleThreadExecutor().execute {
            val times = DiyanetRepository.fetchAndCacheDiyanetTimes(context)
            if (times != null) {
                AlarmScheduler.scheduleAllEnabledAlarms(context, times)
            }
        }
    }
}
