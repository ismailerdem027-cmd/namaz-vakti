package com.sadenamazvakti.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import androidx.core.graphics.drawable.IconCompat

/**
 * Özellik 3:
 * Bildirimin sol üstte (durum çubuğunda) simgesi olur.
 * - Vakte 60 dakikadan fazla varsa: Zarif hilal/cami simgesi gösterir.
 * - Son 1 saat (1..60 dakika) kaldığında: Simgenin içinde doğrudan kalan dakikayı (ör. "45", "12", "5") yazar.
 */
object StatusBarIconGenerator {

    fun createStatusBarIcon(remainingMinutes: Int): IconCompat {
        val size = 72
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        if (remainingMinutes in 1..60) {
            // Son 1 saat içinde: Durum çubuğunda okunaklı büyük dakika sayısı
            val text = remainingMinutes.toString()

            // Üstte ince bir hilal/kubbe kemeri çizgisi
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 4.5f
            val arcRect = RectF(8f, 4f, size - 8f, 26f)
            canvas.drawArc(arcRect, 195f, 150f, false, paint)

            // Dakika metni
            paint.style = Paint.Style.FILL
            paint.textSize = if (text.length == 1) 52f else 44f
            val bounds = Rect()
            paint.getTextBounds(text, 0, text.length, bounds)
            val yPos = (size / 2f) + (bounds.height() / 2f) + 6f
            canvas.drawText(text, size / 2f, yPos, paint)
        } else {
            // 1 saatten fazla varken: Sade Hilal Simgesi
            paint.style = Paint.Style.FILL
            canvas.drawCircle(size / 2f, size / 2f, 26f, paint)

            val cutPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.TRANSPARENT
                xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
            }
            canvas.drawCircle((size / 2f) + 10f, (size / 2f) - 6f, 22f, cutPaint)
        }

        return IconCompat.createWithBitmap(bitmap)
    }
}
