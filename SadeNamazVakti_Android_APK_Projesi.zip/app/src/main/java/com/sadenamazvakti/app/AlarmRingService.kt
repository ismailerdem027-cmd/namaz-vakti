package com.sadenamazvakti.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class AlarmRingService : Service() {
    companion object {
        const val CHANNEL_ID = "sade_namaz_alarm_channel"
        const val NOTIF_ID = 2002
        const val ACTION_STOP_ALARM = "com.sadenamazvakti.app.STOP_ALARM"
    }

    private var mediaPlayer: MediaPlayer? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_ALARM) {
            stopAlarmAndService()
            return START_NOT_STICKY
        }

        val label = intent?.getStringExtra("ALARM_LABEL") ?: "Namaz Vakti"
        val uriStr = intent?.getStringExtra("RINGTONE_URI")
        createAlarmChannel()

        val stopIntent = Intent(this, AlarmRingService::class.java).apply {
            action = ACTION_STOP_ALARM
        }
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Namaz Vakti Hatırlatıcı")
            .setContentText(label)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Alarmı Kapat", stopPending)
            .build()

        startForeground(NOTIF_ID, notif)
        playSelectedRingtone(uriStr)
        return START_NOT_STICKY
    }

    private fun playSelectedRingtone(uriStr: String?) {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()

            val uri = if (!uriStr.isNullOrEmpty()) {
                Uri.parse(uriStr)
            } else {
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            }

            mediaPlayer = MediaPlayer().apply {
                setDataSource(this@AlarmRingService, uri)
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                isLooping = true
                prepare()
                start()
            }
        } catch (_: Exception) {}
    }

    private fun stopAlarmAndService() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (_: Exception) {}
        mediaPlayer = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createAlarmChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Namaz Vakti Alarmları",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Vakitlerde ve öncesinde seçilen zil sesiyle çalan alarm kanalı"
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        stopAlarmAndService()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
