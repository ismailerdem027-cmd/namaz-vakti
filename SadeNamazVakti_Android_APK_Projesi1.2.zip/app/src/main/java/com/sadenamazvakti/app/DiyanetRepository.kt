package com.sadenamazvakti.app

import android.content.Context
import android.location.Geocoder
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DiyanetRepository {
    private const val PREFS_NAME = "diyanet_prayer_prefs"
    private const val KEY_LAT = "lat"
    private const val KEY_LON = "lon"
    private const val KEY_CITY = "city"
    private const val KEY_ILCE_ID = "diyanet_ilce_id"

    // Varsayılan konum: Gaziantep (Diyanet Resmi İlçe Kodu: 9470)
    private const val DEFAULT_LAT = 37.0662
    private const val DEFAULT_LON = 37.3833
    private const val DEFAULT_CITY = "Gaziantep"
    private const val DEFAULT_ILCE_ID = "9470"

    fun saveLocation(context: Context, lat: Double, lon: Double) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        var cityName = prefs.getString(KEY_CITY, DEFAULT_CITY) ?: DEFAULT_CITY
        try {
            val geocoder = Geocoder(context, Locale("tr", "TR"))
            @Suppress("DEPRECATION")
            val addresses = geocoder.getFromLocation(lat, lon, 1)
            if (!addresses.isNullOrEmpty()) {
                val addr = addresses[0]
                cityName = addr.adminArea ?: addr.subAdminArea ?: DEFAULT_CITY
            }
        } catch (_: Exception) {}

        prefs.edit()
            .putString(KEY_LAT, lat.toString())
            .putString(KEY_LON, lon.toString())
            .putString(KEY_CITY, cityName)
            .apply()
    }

    fun getSavedLocation(context: Context): Triple<Double, Double, String> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val lat = prefs.getString(KEY_LAT, null)?.toDoubleOrNull() ?: DEFAULT_LAT
        val lon = prefs.getString(KEY_LON, null)?.toDoubleOrNull() ?: DEFAULT_LON
        val city = prefs.getString(KEY_CITY, DEFAULT_CITY) ?: DEFAULT_CITY
        return Triple(lat, lon, city)
    }

    fun getOffsetMinutes(context: Context, prayerIndex: Int): Int {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt("offset_$prayerIndex", 0)
    }

    fun setOffsetMinutes(context: Context, prayerIndex: Int, offset: Int) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putInt("offset_$prayerIndex", offset).apply()
    }

    private fun applyOffset(timeHhMm: String, offsetMinutes: Int): String {
        if (offsetMinutes == 0) return timeHhMm
        val parts = timeHhMm.split(":")
        if (parts.size != 2) return timeHhMm
        val total = (parts[0].toInt() * 60 + parts[1].toInt() + offsetMinutes + 1440) % 1440
        return String.format(Locale.US, "%02d:%02d", total / 60, total % 60)
    }

    fun applyAllOffsets(context: Context, raw: DailyPrayerTimes): DailyPrayerTimes {
        return raw.copy(
            imsak = applyOffset(raw.imsak, getOffsetMinutes(context, 0)),
            gunes = applyOffset(raw.gunes, getOffsetMinutes(context, 1)),
            ogle = applyOffset(raw.ogle, getOffsetMinutes(context, 2)),
            ikindi = applyOffset(raw.ikindi, getOffsetMinutes(context, 3)),
            aksam = applyOffset(raw.aksam, getOffsetMinutes(context, 4)),
            yatsi = applyOffset(raw.yatsi, getOffsetMinutes(context, 5))
        )
    }

    fun fetchAndCacheDiyanetTimes(context: Context, date: Date = Date()): DailyPrayerTimes? {
        val (lat, lon, city) = getSavedLocation(context)
        val dateKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(date)
        val apiDate = SimpleDateFormat("dd-MM-yyyy", Locale.US).format(date)
        val diyanetDate = SimpleDateFormat("dd.MM.yyyy", Locale.US).format(date)

        getCachedTimes(context, dateKey)?.let { return applyAllOffsets(context, it) }

        // 1. Öncelik: Diyanet e-Mushaf resmi tablo verisi (Gaziantep 9470 veya kayıtlı ilçe)
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val ilceId = prefs.getString(KEY_ILCE_ID, DEFAULT_ILCE_ID) ?: DEFAULT_ILCE_ID
            val emushafUrl = "https://ezanvakti.emushaf.net/vakitler/$ilceId"
            val conn = (URL(emushafUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 6000
                readTimeout = 6000
                requestMethod = "GET"
            }
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val arr = JSONArray(body)
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val miladi = obj.optString("MiladiTarihKisa", "")
                    val dKey = convertMiladiToIso(miladi)
                    val daily = DailyPrayerTimes(
                        dateKey = dKey,
                        cityName = city,
                        imsak = cleanTime(obj.getString("Imsak")),
                        gunes = cleanTime(obj.getString("Gunes")),
                        ogle = cleanTime(obj.getString("Ogle")),
                        ikindi = cleanTime(obj.getString("Ikindi")),
                        aksam = cleanTime(obj.getString("Aksam")),
                        yatsi = cleanTime(obj.getString("Yatsi"))
                    )
                    cacheTimes(context, daily)
                }
                getCachedTimes(context, dateKey)?.let { return applyAllOffsets(context, it) }
            }
        } catch (_: Exception) {}

        // 2. Yedek: Aladhan Diyanet (method=13)
        return try {
            val urlStr = "https://api.aladhan.com/v1/timings/$apiDate?latitude=$lat&longitude=$lon&method=13"
            val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                requestMethod = "GET"
            }
            if (conn.responseCode == 200) {
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                val timings = JSONObject(response)
                    .getJSONObject("data")
                    .getJSONObject("timings")

                val daily = DailyPrayerTimes(
                    dateKey = dateKey,
                    cityName = city,
                    imsak = cleanTime(timings.getString("Fajr")),
                    gunes = cleanTime(timings.getString("Sunrise")),
                    ogle = cleanTime(timings.getString("Dhuhr")),
                    ikindi = cleanTime(timings.getString("Asr")),
                    aksam = cleanTime(timings.getString("Maghrib")),
                    yatsi = cleanTime(timings.getString("Isha"))
                )
                cacheTimes(context, daily)
                applyAllOffsets(context, daily)
            } else {
                applyAllOffsets(context, getFallbackOrCached(context, dateKey, city))
            }
        } catch (e: Exception) {
            applyAllOffsets(context, getFallbackOrCached(context, dateKey, city))
        }
    }

    private fun convertMiladiToIso(ddMmYyyy: String): String {
        val p = ddMmYyyy.split(".")
        return if (p.size == 3) "${p[2]}-${p[1]}-${p[0]}" else ddMmYyyy
    }

    private fun cleanTime(raw: String): String = raw.trim().take(5)

    private fun cacheTimes(context: Context, daily: DailyPrayerTimes) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val json = JSONObject().apply {
            put("dateKey", daily.dateKey)
            put("cityName", daily.cityName)
            put("imsak", daily.imsak)
            put("gunes", daily.gunes)
            put("ogle", daily.ogle)
            put("ikindi", daily.ikindi)
            put("aksam", daily.aksam)
            put("yatsi", daily.yatsi)
        }
        prefs.edit().putString("day_${daily.dateKey}", json.toString()).apply()
    }

    fun getCachedTimes(context: Context, dateKey: String): DailyPrayerTimes? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString("day_$dateKey", null) ?: return null
        return try {
            val j = JSONObject(raw)
            DailyPrayerTimes(
                dateKey = j.getString("dateKey"),
                cityName = j.getString("cityName"),
                imsak = j.getString("imsak"),
                gunes = j.getString("gunes"),
                ogle = j.getString("ogle"),
                ikindi = j.getString("ikindi"),
                aksam = j.getString("aksam"),
                yatsi = j.getString("yatsi")
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun getFallbackOrCached(context: Context, dateKey: String, city: String): DailyPrayerTimes {
        getCachedTimes(context, dateKey)?.let { return it }
        return DailyPrayerTimes(
            dateKey = dateKey,
            cityName = city,
            imsak = "05:34",
            gunes = "06:56",
            ogle = "12:24",
            ikindi = "15:18",
            aksam = "17:41",
            yatsi = "18:58"
        )
    }

    /**
     * Saniyeyi de hesaba katarak kalan tam dakikayı hesaplar (diğer uygulamalarla 1 dk farkı önler).
     * Örn: Vakit 17:41:00, şu an 17:18:25 ise 22 dk 35 sn kalmıştır -> 22 gösterir.
     */
    fun calculateNextPrayer(today: DailyPrayerTimes): NextPrayerInfo {
        val now = Calendar.getInstance()
        val nowSeconds = now.get(Calendar.HOUR_OF_DAY) * 3600 +
            now.get(Calendar.MINUTE) * 60 +
            now.get(Calendar.SECOND)

        for ((name, timeStr) in today.asOrderedList()) {
            val parts = timeStr.split(":")
            if (parts.size == 2) {
                val pSeconds = parts[0].toInt() * 3600 + parts[1].toInt() * 60
                if (pSeconds > nowSeconds) {
                    val diffSeconds = pSeconds - nowSeconds
                    val remainingMins = (diffSeconds / 60).coerceAtLeast(1)
                    return NextPrayerInfo(
                        prayerName = name,
                        prayerTime = timeStr,
                        remainingMinutes = remainingMins,
                        todayTimes = today
                    )
                }
            }
        }

        val parts = today.imsak.split(":")
        val imsakSeconds = parts[0].toInt() * 3600 + parts[1].toInt() * 60
        val diffSeconds = (24 * 3600 - nowSeconds) + imsakSeconds
        val remainingMins = (diffSeconds / 60).coerceAtLeast(1)
        return NextPrayerInfo(
            prayerName = "İmsak",
            prayerTime = today.imsak,
            remainingMinutes = remainingMins,
            todayTimes = today
        )
    }
}
