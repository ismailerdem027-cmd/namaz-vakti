package com.sadenamazvakti.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import java.util.concurrent.Executors

class PrayerForegroundService : Service() {

    companion object {
        // Kilit ekranında görünmesi için IMPORTANCE_DEFAULT kullanan yeni kanal kimliği
        const val CHANNEL_ID = "sade_namaz_kilit_ekrani_v2"
        const val NOTIFICATION_ID = 1001
    }

    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var lastDisplayedMinute: Int = -1

    private val periodicTick = object : Runnable {
        override fun run() {
            refreshNotificationAsync()
            mainHandler.postDelayed(this, 20_000L)
        }
    }

    private val timeTickReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshNotificationAsync()
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()

        val fallback = DiyanetRepository.fetchAndCacheDiyanetTimes(this)
        if (fallback != null) {
            val nextInfo = DiyanetRepository.calculateNextPrayer(fallback)
            lastDisplayedMinute = nextInfo.remainingMinutes
            startForeground(NOTIFICATION_ID, buildOngoingNotification(nextInfo))
        }

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        registerReceiver(timeTickReceiver, filter)
        mainHandler.post(periodicTick)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        refreshNotificationAsync()
        return START_STICKY
    }

    private fun refreshNotificationAsync() {
        executor.execute {
            val times = DiyanetRepository.fetchAndCacheDiyanetTimes(this) ?: return@execute
            val nextInfo = DiyanetRepository.calculateNextPrayer(times)
            val notification = buildOngoingNotification(nextInfo)
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIFICATION_ID, notification)
            AlarmScheduler.scheduleAllEnabledAlarms(this, times)
        }
    }

    private fun buildOngoingNotification(info: NextPrayerInfo): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val hours = info.remainingMinutes / 60
        val mins = info.remainingMinutes % 60
        val countdownStr = if (hours > 0) "${hours} sa ${mins} dk" else "${mins} dk"

        val t = info.todayTimes
        val title = "${info.prayerName} vaktine $countdownStr (${info.prayerTime}) • ${t.cityName}"
        val compactLine = "İms:${t.imsak} Gün:${t.gunes} Öğl:${t.ogle} İkn:${t.ikindi} Akş:${t.aksam} Yat:${t.yatsi}"
        val expandedText = "İmsak: ${t.imsak}   |   Güneş: ${t.gunes}   |   Öğle: ${t.ogle}\nİkindi: ${t.ikindi}   |   Akşam: ${t.aksam}   |   Yatsı: ${t.yatsi}"

        val smallIcon = StatusBarIconGenerator.createStatusBarIcon(info.remainingMinutes)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(smallIcon)
            .setContentTitle(title)
            .setContentText(compactLine)
            .setStyle(NotificationCompat.BigTextStyle().bigText(expandedText))
            .setOngoing(true)
            .setAutoCancel(false)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT) // Kilit ekranında görünmesi için DEFAULT
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC) // Kilit ekranında tam içerik göster
            .setContentIntent(pendingIntent)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Namaz Vakitleri (Kilit Ekranı & Durum Çubuğu)",
                NotificationManager.IMPORTANCE_DEFAULT // LOW olursa Android kilit ekranında gizler
            ).apply {
                description = "Namaz vakitlerini bildirimde ve kilit ekranında sessiz olarak sürekli gösterir"
                setSound(null, null)
                enableVibration(false)
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        mainHandler.removeCallbacks(periodicTick)
        try {
            unregisterReceiver(timeTickReceiver)
        } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
